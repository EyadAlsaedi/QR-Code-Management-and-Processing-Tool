﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Drawing.Imaging;
using QRCoder;
using ZXing;
using AForge.Video;
using AForge.Video.DirectShow;

namespace QRMTP
{
    public partial class QRMain : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectRgn
    (
        int nLeftRect,
        int nTopRect,
        int nRightRect,
        int nBottomRect,
        int nWidthEllipse,
        int nHeightEllipse
    );

        public QRMain()
        {
            InitializeComponent();
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 25, 25));
            panel3.Show();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();

        }
        FilterInfoCollection fic;
        VideoCaptureDevice vcd;

        

        private void QRMain_Load_1(object sender, EventArgs e)
        {
            fic = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            if (fic.Count > 0)
            {
                foreach (FilterInfo filterInfo in fic)
                    comboBox1.Items.Add(filterInfo.Name);
                comboBox1.SelectedIndex = 0;
            }
        }

        private void exit_Click(object sender, EventArgs e)
        {
            if (vcd != null)
                vcd.Stop();
            this.Close();
        }

        private void home_Click(object sender, EventArgs e)
        {
            if (vcd != null)
            {
                vcd.Stop();
            }
            pnlNav.Height = home.Height;
            pnlNav.Top = home.Top;
            pnlNav.Left = home.Left;
            home.BackColor = Color.FromArgb(31, 31, 31);
            panel3.Show();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (vcd != null)
            {
                vcd.Stop();
            }
            pnlNav.Height = home.Height;
            pnlNav.Top = home.Top;
            pnlNav.Left = home.Left;
            home.BackColor = Color.FromArgb(31, 31, 31);
            panel3.Hide();
            panel4.Show();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
        }

        private void qrscan_Click(object sender, EventArgs e)
        {
            if (vcd != null)
            {
                vcd.Stop();
            }
            pnlNav.Height = home.Height;
            pnlNav.Top = home.Top;
            pnlNav.Left = home.Left;
            home.BackColor = Color.FromArgb(31, 31, 31);
            panel3.Hide();
            panel4.Hide();
            panel5.Show();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
        }

        private void contact_Click(object sender, EventArgs e)
        {
            pnlNav.Height = cam.Height;
            pnlNav.Top = cam.Top;
            pnlNav.Left = cam.Left;
            cam.BackColor = Color.FromArgb(31, 31, 31);
            panel6.Show();
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel7.Hide();
            panel8.Hide();
            
        }

        private void panel1_Leave(object sender, EventArgs e)
        {

        }

        private void home_Leave(object sender, EventArgs e)
        {
            home.BackColor = Color.FromArgb(51, 51, 51);
            

        }

        private void qrgenerate_Leave(object sender, EventArgs e)
        {
            qrgenerate.BackColor = Color.FromArgb(51, 51, 51);
            
        }

        private void qrscan_Leave(object sender, EventArgs e)
        {
            qrscan.BackColor = Color.FromArgb(51, 51, 51);
            
        }

        private void contact_Leave(object sender, EventArgs e)
        {
            cam.BackColor = Color.FromArgb(51, 51, 51);
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            QRCodeGenerator qg = new QRCodeGenerator();
            
            QRCodeData data = qg.CreateQrCode(textBox1.Text, QRCodeGenerator.ECCLevel.Q);
            QRCode code = new QRCode(data);
            pictureBox2.Image = code.GetGraphic(5);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pictureBox2.Image = null;
            textBox1.Text = "";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            BarcodeReader bcr = new BarcodeReader();

            try
            {
                Result r = bcr.Decode((Bitmap)pictureBox3.Image);
                string decoded = r.ToString().Trim();
                if (decoded != "")
                {
                    textBox3.Text = decoded;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("You need to Upload a QR Code first!", "Error");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Open Image";
            //ofd.Filter = "bmp files(*.bmp)|*.bmp";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox3.Image = new Bitmap(ofd.FileName);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = null;
            textBox3.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (pictureBox2.Image != null)
            {
                string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                pictureBox2.Image.Save(path + "\\" + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString() + ".jpg", ImageFormat.Jpeg);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (fic.Count == 0)
            {
                MessageBox.Show("No camera found!");
                return;
            }

            int selectedIndex = comboBox1.SelectedIndex;
            if (selectedIndex < 0 || selectedIndex >= fic.Count)
            {
                MessageBox.Show("Invalid camera selection!");
                return;
            }

            vcd = new VideoCaptureDevice(fic[selectedIndex].MonikerString);
            vcd.NewFrame += Vcd_NewFrame;
            vcd.Start();
            timer1.Start();
        }

        private void Vcd_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            pictureBox4.Image = (Bitmap)eventArgs.Frame.Clone();
        }

        private void QRMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (vcd != null && vcd.IsRunning)
                vcd.Stop();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (pictureBox4.Image != null)
            {
                BarcodeReader bcr = new BarcodeReader();
                Result r = bcr.Decode((Bitmap)pictureBox4.Image);
                if (r != null) {

                    textBox2.Text = r.ToString();
                    timer1.Stop();
                    if (vcd.IsRunning)
                        vcd.Stop();
                }

                
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            BarcodeReader bcr = new BarcodeReader();

            try
            {
                Result r = bcr.Decode((Bitmap)pictureBox6.Image);
                string decoded = r.ToString().Trim();
                if (decoded != "")
                {

                    int shift = 13;
                    string plainText = "";
                    foreach (char c in decoded)
                    {
                        if (char.IsLetter(c))
                        {
                            char newChar = (char)((((c - 65) - shift + 26) % 26) + 65);
                            plainText += newChar;
                        }
                        else
                        {
                            plainText += c;
                        }
                    }
                    textBox5.Text = plainText;

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("You need to Upload a QR Code first!", "Error");
            }
            QRCodeGenerator qg = new QRCodeGenerator();

            QRCodeData data = qg.CreateQrCode(textBox5.Text, QRCodeGenerator.ECCLevel.Q);
            QRCode code = new QRCode(data);
            pictureBox6.Image = code.GetGraphic(5);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (pictureBox6.Image != null)
            {
                string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                pictureBox6.Image.Save(path + "\\" + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString() + ".jpg", ImageFormat.Jpeg);
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Open Image";
            //ofd.Filter = "bmp files(*.bmp)|*.bmp";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox6.Image = new Bitmap(ofd.FileName);
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            pictureBox6.Image = null;
            textBox5.Text = "";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            BarcodeReader bcr = new BarcodeReader();

            try
            {
                Result r = bcr.Decode((Bitmap)pictureBox5.Image);
                string decoded = r.ToString().Trim();
                if (decoded != "")
                {

                    int shift = 7;
                    string plainText = decoded;
                    string cipherText = "";

                    foreach (char c in plainText)
                    {
                        if (char.IsLetter(c))
                        {
                            char newChar = (char)(((int)c + shift - 65) % 26 + 65);
                            cipherText += newChar;
                        }
                        else
                        {
                            cipherText += c;
                        }
                    }
                    textBox4.Text = cipherText;

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("You need to Upload a QR Code first!", "Error");
            }
            QRCodeGenerator qg = new QRCodeGenerator();

            QRCodeData data = qg.CreateQrCode(textBox4.Text, QRCodeGenerator.ECCLevel.Q);
            QRCode code = new QRCode(data);
            pictureBox5.Image = code.GetGraphic(5);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (pictureBox5.Image != null)
            {
                string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                pictureBox5.Image.Save(path + "\\" + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString() + ".jpg", ImageFormat.Jpeg);
            }
        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            pictureBox5.Image = null;
            textBox4.Text = "";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Open Image";
            //ofd.Filter = "bmp files(*.bmp)|*.bmp";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox5.Image = new Bitmap(ofd.FileName);
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (vcd != null)
            {
                vcd.Stop();
            }
            pnlNav.Height = home.Height;
            pnlNav.Top = home.Top;
            pnlNav.Left = home.Left;
            home.BackColor = Color.FromArgb(31, 31, 31);
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Show();
            panel8.Hide();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (vcd != null)
            {
                vcd.Stop();
            }
            pnlNav.Height = home.Height;
            pnlNav.Top = home.Top;
            pnlNav.Left = home.Left;
            home.BackColor = Color.FromArgb(31, 31, 31);
            panel3.Hide();
            panel4.Hide();
            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Show();
        }
    }
}
